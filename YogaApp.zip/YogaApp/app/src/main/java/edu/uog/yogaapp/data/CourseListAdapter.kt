package edu.uog.yogaapp.data


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import edu.uog.yogaapp.R


class CourseListAdapter(context: Context, courseList: ArrayList<Course>) : BaseAdapter() {
    interface OnClickListener{
        fun onDetailClick(position: Int)
        fun onEditClick(position: Int)
        fun onRemoveClick(position: Int)
    }

    private val context = context
    var courseList:ArrayList<Course> = courseList
    private var listener: OnClickListener? =null

    open fun setOnClickListener(listener: OnClickListener){this.listener=listener}
    override fun getCount(): Int { return courseList.count() }
    override fun getItem(position: Int): Any { return courseList[position] }
    override fun getItemId(position: Int): Long { return courseList[position].id!!.toLong() }

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {

        val inflater = LayoutInflater.from(context).inflate(R.layout.course_list, parent, false)
        val lblDayOfWeek = inflater.findViewById(R.id.lblCourseListDayOfWeek) as TextView
        val lblTimeOfCourse = inflater.findViewById(R.id.lblCourseListTimeOfCourse) as TextView
        val lblPrice = inflater.findViewById(R.id.lblCourseListPrice) as TextView
        val btnListDetail =inflater.findViewById(R.id.btnCourseListDetail) as Button
        val btnListEdit =inflater.findViewById(R.id.btnCourseListEdit) as Button
        val btnListRemove =inflater.findViewById(R.id.btnCourseListRemove) as Button

        lblDayOfWeek.text = courseList[position].dayOfWeek
        lblTimeOfCourse.text = courseList[position].timeOfCourse
        lblPrice.text = "%.0f".format(courseList[position].pricePerClass)

        btnListDetail.setOnClickListener(View.OnClickListener { v->
            listener?.onDetailClick(position) })
        btnListEdit.setOnClickListener(View.OnClickListener { v->
            listener?.onEditClick(position) })
        btnListRemove.setOnClickListener(View.OnClickListener { v->
            listener?.onRemoveClick(position) })

        return inflater
    }
}