package edu.uog.yogaapp.data

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import edu.uog.yogaapp.CourseEntryActivity
import edu.uog.yogaapp.R

class CourseDetailActivity : AppCompatActivity() {
    lateinit var lblDetailDayOfWeek: TextView
    lateinit var lblDetailTimeOfCourse: TextView
    lateinit var lblDetailCapacity: TextView
    lateinit var lblDetailDuration: TextView
    lateinit var lblDetailPricePerClass: TextView
    lateinit var lblDetailTypeOfClass: TextView
    lateinit var lblDetailDescription: TextView
    lateinit var lblDetailAdditional1: TextView
    lateinit var lblDetailAdditional2: TextView
    var id: Int? =null
    var dayOfWeek: String? =null
    lateinit var btnAddInstance: Button
    lateinit var lstInstance: ListView
    lateinit var instanceListAdapter: InstanceListAdapter
    var instanceList:ArrayList<Instance> = ArrayList<Instance>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_detail)

        lblDetailDayOfWeek =findViewById(R.id.lblDetailDayOfWeek)
        lblDetailTimeOfCourse =findViewById(R.id.lblDetailTimeOfCourse)
        lblDetailCapacity =findViewById(R.id.lblDetailCapacity)
        lblDetailDuration =findViewById(R.id.lblDetailDuration)
        lblDetailPricePerClass =findViewById(R.id.lblDetailPricePerClass)
        lblDetailTypeOfClass =findViewById(R.id.lblDetailTypeOfClass)
        lblDetailDescription =findViewById(R.id.lblDetailDescription)
        lblDetailAdditional1 =findViewById(R.id.lblDetailAdditional1)
        lblDetailAdditional2 =findViewById(R.id.lblDetailAdditional2)

        val bundle: Bundle? = intent.extras
        id =bundle?.getInt("ID")
        dayOfWeek =bundle?.getString("DAY_OF_WEEK")

        lblDetailDayOfWeek.text ="Day of week: "+ bundle?.getString("DAY_OF_WEEK")
        lblDetailTimeOfCourse.text ="Time of course: " + bundle?.getString("TIME_OF_COURSE")
        lblDetailCapacity.text ="Capacity: " + bundle?.getInt("CAPACITY")
        lblDetailDuration.text ="Duration: " + bundle?.getInt("DURATION")
        lblDetailPricePerClass.text ="Price: " + "%.0f".format(bundle?.getDouble("PRICE"))
        lblDetailTypeOfClass.text ="Type of class: " + bundle?.getString("TYPE_OF_CLASS")
        lblDetailDescription.text ="Description: " + bundle?.getString("DESCRIPTION")
        lblDetailAdditional1.text ="Additional1: " + bundle?.getString("ADDITIONAL1")
        lblDetailAdditional2.text ="Additional2: " + bundle?.getString("ADDITIONAL2")

        btnAddInstance =findViewById(R.id.btnAddInstance)
        lstInstance =findViewById(R.id.lstInstance)
        instanceListAdapter = InstanceListAdapter(this, instanceList)
        lstInstance.adapter = instanceListAdapter

        val obj = object :InstanceListAdapter.OnClickListener{

            override fun onEditClick(position: Int){
                var instance =instanceList[position]

                val intent =Intent(baseContext, InstanceEntryActivity::class.java)
                intent.putExtra("COURSE_ID", id)
                intent.putExtra("DAY_OF_WEEK", dayOfWeek)

                intent.putExtra("DATE", instance.date)
                intent.putExtra("ID", instance.id)
                intent.putExtra("TEACHER", instance.teacher)
                intent.putExtra("COMMENT", instance.comment)
                startActivity(intent)
            }

            override fun onRemoveClick(position: Int){
                var instance =instanceList[position]
                val databaseHandler: DatabaseHandler = DatabaseHandler(baseContext)
                databaseHandler.deleteInstance(instance.id)
                viewInstance()
            }
        }
        instanceListAdapter.setOnClickListener(obj)

        viewInstance()

        btnAddInstance.setOnClickListener(View.OnClickListener { v->
            val intent =Intent(baseContext, InstanceEntryActivity::class.java)
            intent.putExtra("COURSE_ID", id)
            intent.putExtra("DAY_OF_WEEK", dayOfWeek)
            startActivity(intent)
        })
    }

    private fun viewInstance(){
        val databaseHandler: DatabaseHandler = DatabaseHandler(this)
        instanceList = databaseHandler.viewInstance( id!! )
        instanceListAdapter.instanceList =instanceList
        instanceListAdapter.notifyDataSetChanged()
    }
}