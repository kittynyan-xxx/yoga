package edu.uog.yogaapp.data


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import edu.uog.yogaapp.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class InstanceListAdapter(context: Context, instanceList: ArrayList<Instance>) : BaseAdapter() {
    interface OnClickListener{
        fun onEditClick(position: Int)
        fun onRemoveClick(position: Int)
    }

    private val context = context
    var instanceList:ArrayList<Instance> = instanceList
    private var listener: OnClickListener? =null

    open fun setOnClickListener(listener: OnClickListener){this.listener=listener}
    override fun getCount(): Int { return instanceList.count() }
    override fun getItem(position: Int): Any { return instanceList[position] }
    override fun getItemId(position: Int): Long { return instanceList[position].id!!.toLong() }

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {

        val inflater = LayoutInflater.from(context).inflate(R.layout.instance_list, parent, false)
        val lblDate = inflater.findViewById(R.id.lblInstanceListDate) as TextView
        val lblTeacher = inflater.findViewById(R.id.lblInstanceListTeacher) as TextView
        val lblComment = inflater.findViewById(R.id.lblInstanceListComment) as TextView

        val btnListEdit =inflater.findViewById(R.id.btnInstanceListEdit) as Button
        val btnListRemove =inflater.findViewById(R.id.btnInstanceListRemove) as Button

        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val formattedDate = dateFormat.format(Date(instanceList[position].date!!))

        lblDate.text = formattedDate
        lblTeacher.text = instanceList[position].teacher
        lblComment.text = instanceList[position].comment

        btnListEdit.setOnClickListener(View.OnClickListener { v->
            listener?.onEditClick(position) })
        btnListRemove.setOnClickListener(View.OnClickListener { v->
            listener?.onRemoveClick(position) })

        return inflater
    }
}