package edu.uog.yogaapp.data

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import edu.uog.yogaapp.R
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class InstanceEntryActivity : AppCompatActivity() {
    lateinit var txtInstanceDate : TextView
    lateinit var txtInstanceTeacher : EditText
    lateinit var txtInstanceComment : EditText
    lateinit var btnInstanceSave : Button
    var courseId: Int? =null
    var dayOfWeek: String? =null
    lateinit var date : Date
    var id: Int? =null
    lateinit var instance: Instance


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_instance_entry)

        txtInstanceDate =findViewById(R.id.txtInstanceDate)
        txtInstanceTeacher =findViewById(R.id.txtInstanceTeacher)
        txtInstanceComment =findViewById(R.id.txtInstanceComment)
        btnInstanceSave =findViewById(R.id.btnInstanceSave)

        val bundle: Bundle? = intent.extras
        courseId =bundle?.getInt("COURSE_ID")
        dayOfWeek =bundle?.getString("DAY_OF_WEEK")
        val dateLong =bundle?.getLong("DATE", 0)
        if( dateLong!! > 0){
            id =bundle?.getInt("ID")
            date =Date(dateLong)
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val formattedDate = dateFormat.format(date.time)
            txtInstanceDate.text = formattedDate
            txtInstanceTeacher.setText(bundle?.getString("TEACHER"))
            txtInstanceComment.setText(bundle?.getString("COMMENT"))
        }

    }


    private val calendar = Calendar.getInstance()
    open fun showDatePicker(view: View) {
        val datePickerDialog = DatePickerDialog(
            this, {DatePicker, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, monthOfYear, dayOfMonth)
                var selectedDayOfWeek =checkDay(selectedDate.time.day)
                if( selectedDayOfWeek.equals(dayOfWeek)) {
                    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    val formattedDate = dateFormat.format(selectedDate.time)
                    txtInstanceDate.text = formattedDate
                    date = selectedDate.time
                }else{
                    Toast.makeText(baseContext,"Course day is $dayOfWeek but you have selected $selectedDayOfWeek" ,
                        Toast.LENGTH_LONG).show()
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    fun checkDay(dayInt : Int) : String {
        if( dayInt ==0)
            return "Sunday"
        else if( dayInt ==1)
        return "Monday"
        else if( dayInt ==2)
            return "Tuesday"
        else if( dayInt ==3)
            return "Wednesday"
        else if( dayInt ==4)
            return "Thursday"
        else if( dayInt ==5)
            return "Friday"
        else
            return "Saturday"
    }

    open fun saveInstance(view: View){
        instance =Instance (id, courseId, date.time,
            txtInstanceTeacher.text.toString(), txtInstanceComment.text.toString())

        val databaseHandler: DatabaseHandler =DatabaseHandler(this)
        if( instance.id !=null && instance.id!!>0){
            //updating
            var status =databaseHandler.updateInstance(instance)
            if(status > 0){
                Toast.makeText(baseContext,"Record updated!", Toast.LENGTH_LONG).show()
                finish()
            }else{
                Toast.makeText(baseContext,"Failed to update!", Toast.LENGTH_LONG).show()
            }
        }else {
            var status = databaseHandler.addInstance(instance)
            if (status > 0) {
                Toast.makeText(baseContext, "Record saved!", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(baseContext, "Failed to save!", Toast.LENGTH_LONG).show()
            }
        }
    }
}