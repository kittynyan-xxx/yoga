package edu.uog.yogaapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast

class CourseEntryActivity : AppCompatActivity() {
    lateinit var spnDayOfWeek: Spinner
    lateinit var spnTimeOfCourse: Spinner
    lateinit var txtCapacity: EditText
    lateinit var txtDuration: EditText
    lateinit var txtPricePerClass: EditText
    lateinit var spnTypeOfClass: Spinner
    lateinit var txtDescription: EditText
    lateinit var txtAdditional1: EditText
    lateinit var txtAdditional2: EditText
    lateinit var btnCourseEntryNext: Button
    private var id: Int =0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_entry)

        spnDayOfWeek =findViewById(R.id.spnDayOfWeek)
        spnTimeOfCourse =findViewById(R.id.spnTimeOfCourse)
        txtCapacity =findViewById(R.id.txtCapacity)
        txtDuration =findViewById(R.id.txtDuration)
        txtPricePerClass =findViewById(R.id.txtPricePerClass)
        spnTypeOfClass =findViewById(R.id.spnTypeOfClass)
        txtDescription =findViewById(R.id.txtDescription)
        txtAdditional1 =findViewById(R.id.txtAdditional1)
        txtAdditional2 =findViewById(R.id.txtAdditional2)
        btnCourseEntryNext =findViewById(R.id.btnCourseEntryNext)

        edit()
    }

    open fun next(view: View){
        if( !isValid() ) return
        val intent = Intent(this, CourseEntryDetailActivity::class.java)
        intent.putExtra("ID", id)
        intent.putExtra("DAY_OF_WEEK", spnDayOfWeek.selectedItem.toString())
        intent.putExtra("TIME_OF_COURSE", spnTimeOfCourse.selectedItem.toString())
        intent.putExtra("CAPACITY", txtCapacity.text.toString())
        intent.putExtra("DURATION", txtDuration.text.toString())
        intent.putExtra("PRICE", txtPricePerClass.text.toString())
        intent.putExtra("TYPE_OF_CLASS", spnTypeOfClass.selectedItem.toString())
        intent.putExtra("DESCRIPTION", txtDescription.text.toString())
        intent.putExtra("ADDITIONAL1", txtAdditional1.text.toString())
        intent.putExtra("ADDITIONAL2", txtAdditional2.text.toString())
        startActivity(intent)
    }

    fun isValid(): Boolean{
        var name =txtCapacity.text;
        if( name ==null || name.isEmpty() ){
            Toast.makeText(this,"Please enter the capacity", Toast.LENGTH_LONG).show()
            txtCapacity.requestFocus()
            return false
        }

        var destination =txtDuration.text;
        if( destination ==null || destination.isEmpty() ){
            Toast.makeText(this, "Please enter the duration in minutes", Toast.LENGTH_LONG).show()
            txtDuration.requestFocus()
            return false
        }

        var date =txtPricePerClass.text
        if( date ==null || date.isEmpty() ){
            Toast.makeText(this, "Please enter the price per class", Toast.LENGTH_LONG).show()
            txtPricePerClass.requestFocus()
            return false
        }
        return true;
    }

    open fun cancel(view: View){
        finish()
    }

    fun edit(){
        val bundle: Bundle? = intent.extras
        if( bundle !=null ){
            id =bundle.getInt("ID")
            var dayOfWeek =bundle.getString("DAY_OF_WEEK")
            spnDayOfWeek.setSelection(resources.getStringArray(R.array.daysOfWeek).indexOf(dayOfWeek))
            var timeOfCourse =bundle.getString("TIME_OF_COURSE")
            spnTimeOfCourse.setSelection(resources.getStringArray(R.array.timeOfCourse).indexOf(timeOfCourse))
            txtCapacity.setText( bundle?.getInt("CAPACITY").toString() )
            txtDuration.setText( bundle?.getInt("DURATION").toString())
            txtPricePerClass.setText( "%.0f".format( bundle?.getDouble("PRICE")) )
            var typeOfClass =bundle.getString("TYPE_OF_CLASS")
            spnTypeOfClass.setSelection(resources.getStringArray(R.array.typeOfClass).indexOf(typeOfClass))
            txtDescription.setText(bundle?.getString("DESCRIPTION"))
            txtAdditional1.setText(bundle?.getString("ADDITIONAL1"))
            txtAdditional2.setText(bundle?.getString("ADDITIONAL2"))
        }

    }
}