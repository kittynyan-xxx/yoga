package edu.uog.yogaapp.data

class Course (var id: Int?, var dayOfWeek: String, var timeOfCourse: String,
              var capacity: Int?, var duration: Int, var pricePerClass: Double,
              var typeOfClass: String, var description: String,
              var str1: String?, var str2: String?, var num1: Double?, var num2: Double?)