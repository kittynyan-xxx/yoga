package edu.uog.yogaapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import edu.uog.yogaapp.data.Course
import edu.uog.yogaapp.data.DatabaseHandler


class CourseEntryDetailActivity : AppCompatActivity() {
    lateinit var lblEntryDetailDayOfWeek: TextView
    lateinit var lblEntryDetailTimeOfCourse: TextView
    lateinit var lblEntryDetailCapacity: TextView
    lateinit var lblEntryDetailDuration: TextView
    lateinit var lblEntryDetailPricePerClass: TextView
    lateinit var lblEntryDetailTypeOfClass: TextView
    lateinit var lblEntryDetailDescription: TextView
    lateinit var lblEntryDetailAdditional1: TextView
    lateinit var lblEntryDetailAdditional2: TextView
    lateinit var btnEntryDetailBack: Button
    lateinit var btnEntryDetailSave: Button
    var id: Int? =null
    lateinit var course: Course


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_entry_detail)

        lblEntryDetailDayOfWeek =findViewById(R.id.lblEntryDetailDayOfWeek)
        lblEntryDetailTimeOfCourse =findViewById(R.id.lblEntryDetailTimeOfCourse)
        lblEntryDetailCapacity =findViewById(R.id.lblEntryDetailCapacity)
        lblEntryDetailDuration =findViewById(R.id.lblEntryDetailDuration)
        lblEntryDetailPricePerClass =findViewById(R.id.lblEntryDetailPricePerClass)
        lblEntryDetailTypeOfClass =findViewById(R.id.lblEntryDetailTypeOfClass)
        lblEntryDetailDescription =findViewById(R.id.lblEntryDetailDescription)
        lblEntryDetailAdditional1 =findViewById(R.id.lblEntryDetailAdditional1)
        lblEntryDetailAdditional2 =findViewById(R.id.lblEntryDetailAdditional2)
        btnEntryDetailBack =findViewById(R.id.btnEntryDetailBack)
        btnEntryDetailSave =findViewById(R.id.btnEntryDetailSave)

        val bundle: Bundle? = intent.extras
        id =bundle?.getInt("ID")
        lblEntryDetailDayOfWeek.text ="Day of week: "+ bundle?.getString("DAY_OF_WEEK")
        lblEntryDetailTimeOfCourse.text ="Time of course: " + bundle?.getString("TIME_OF_COURSE")
        lblEntryDetailCapacity.text ="Capacity: " + bundle?.getString("CAPACITY")
        lblEntryDetailDuration.text ="Duration (minutes): " + bundle?.getString("DURATION")
        lblEntryDetailPricePerClass.text ="Price: " + bundle?.getString("PRICE")
        lblEntryDetailTypeOfClass.text ="Type of class: " + bundle?.getString("TYPE_OF_CLASS")
        lblEntryDetailDescription.text ="Description: " + bundle?.getString("DESCRIPTION")
        lblEntryDetailAdditional1.text ="Additional1: " + bundle?.getString("ADDITIONAL1")
        lblEntryDetailAdditional2.text ="Additional2: " + bundle?.getString("ADDITIONAL2")

        course = Course(id, bundle?.getString("DAY_OF_WEEK")!!,
            bundle?.getString("TIME_OF_COURSE")!!,
            bundle?.getString("CAPACITY")!!.toInt(),
            bundle?.getString("DURATION")!!.toInt(),
            bundle?.getString("PRICE")!!.toDouble(),
            bundle?.getString("TYPE_OF_CLASS")!!,
            bundle?.getString("DESCRIPTION")!!,
            bundle?.getString("ADDITIONAL1")!!,
            bundle?.getString("ADDITIONAL2")!!,
            null, null)

        btnEntryDetailBack.setOnClickListener(View.OnClickListener { v->
            finish()
        })
    }

    open fun save(view: View){
        val databaseHandler: DatabaseHandler =DatabaseHandler(this)

        if( course.id !=null && course.id!!>0){
            //updating
            var status =databaseHandler.updateCourse(course)
            if(status > 0){
                Toast.makeText(baseContext,"Record updated!", Toast.LENGTH_LONG).show()
                finish()
            }else{
                Toast.makeText(baseContext,"Failed to update!", Toast.LENGTH_LONG).show()
            }
        }else {
            var status = databaseHandler.addCourse(course)
            if (status > 0) {
                Toast.makeText(baseContext, "Record saved!", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(baseContext, "Failed to save!", Toast.LENGTH_LONG).show()
            }
        }
    }
}