package edu.uog.yogaapp.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import java.util.Date

class DatabaseHandler(context: Context):
    SQLiteOpenHelper(context,DATABASE_NAME,null,DATABASE_VERSION) {
    companion object{
        private val DATABASE_VERSION = 1
        private val DATABASE_NAME = "YogaDatabase"
        private val TABLE_COURSE = "course"
        private val COURSE_KEY_ID = "id"
        private val COURSE_KEY_DAY_OF_WEEK = "dayOfWeek"
        private val COURSE_KEY_TIME_OF_COURSE = "timeOfCourse"
        private val COURSE_KEY_CAPACITY = "capacity"
        private val COURSE_KEY_DURATION = "duration"
        private val COURSE_KEY_PRICE_PER_CLASS = "pricePerClass"
        private val COURSE_KEY_TYPE_OF_CLASS = "typeOfClass"
        private val COURSE_KEY_DESCRIPTION = "description"
        private val COURSE_KEY_STR1 = "str1"
        private val COURSE_KEY_STR2 = "str2"
        private val COURSE_KEY_NUM1 = "num1"
        private val COURSE_KEY_NUM2 = "num2"

        private val TABLE_INSTANCE = "instance"
        private val INSTANCE_KEY_ID="id"
        private val INSTANCE_KEY_COURSE_ID="course_id"
        private val INSTANCE_KEY_DATE = "instanceDate"
        private val INSTANCE_KEY_TEACHER="teacher"
        private val INSTANCE_KEY_COMMENT="comment"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL( "PRAGMA encoding ='UTF-8'" )
        db?.execSQL( "PRAGMA foreign_keys = ON" )

        val CREATE_COURSE_TABLE = ("CREATE TABLE IF NOT EXISTS " + TABLE_COURSE + "("
                + COURSE_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COURSE_KEY_DAY_OF_WEEK + " TEXT,"
                + COURSE_KEY_TIME_OF_COURSE + " TEXT,"
                + COURSE_KEY_CAPACITY + " INT,"
                + COURSE_KEY_DURATION +" INT,"
                + COURSE_KEY_PRICE_PER_CLASS+ " DOUBLE,"
                + COURSE_KEY_TYPE_OF_CLASS+ " TEXT,"
                + COURSE_KEY_DESCRIPTION+ " TEXT,"
                + COURSE_KEY_STR1+ " TEXT,"
                + COURSE_KEY_STR2+ " TEXT,"
                + COURSE_KEY_NUM1+ " DOUBLE,"
                + COURSE_KEY_NUM2+ " DOUBLE" + ")")
        db?.execSQL(CREATE_COURSE_TABLE)

        val CREATE_INSTANCE_TABLE = ("CREATE TABLE IF NOT EXISTS " + TABLE_INSTANCE + "("
                + INSTANCE_KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + INSTANCE_KEY_COURSE_ID + " INTEGER,"
                + INSTANCE_KEY_DATE + " BIGINT,"
                + INSTANCE_KEY_TEACHER + " TEXT,"
                + INSTANCE_KEY_COMMENT+ " TEXT," +
                " CONSTRAINT fk_course FOREIGN KEY (" + INSTANCE_KEY_COURSE_ID + ")" +
                " REFERENCES " + TABLE_COURSE +"(" + COURSE_KEY_ID + ")" +
                " ON UPDATE CASCADE " +
                " ON DELETE CASCADE)")
        db?.execSQL(CREATE_INSTANCE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSE)
        onCreate(db)
    }

    fun addCourse(course: Course): Long{
        var db =this.writableDatabase
        var contentValues =ContentValues()

        contentValues.put(COURSE_KEY_DAY_OF_WEEK, course.dayOfWeek)
        contentValues.put(COURSE_KEY_TIME_OF_COURSE, course.timeOfCourse)
        contentValues.put(COURSE_KEY_CAPACITY, course.capacity)
        contentValues.put(COURSE_KEY_DURATION, course.duration)
        contentValues.put(COURSE_KEY_PRICE_PER_CLASS, course.pricePerClass)
        contentValues.put(COURSE_KEY_TYPE_OF_CLASS, course.typeOfClass)
        contentValues.put(COURSE_KEY_DESCRIPTION, course.description)
        contentValues.put(COURSE_KEY_STR1, course.str1)
        contentValues.put(COURSE_KEY_STR2, course.str2)
        contentValues.put(COURSE_KEY_NUM1, course.num1)
        contentValues.put(COURSE_KEY_NUM2, course.num2)
        val success = db.insert(TABLE_COURSE, null, contentValues)
        db.close(); return success
    }

    fun updateCourse(course: Course): Int{
        var db =this.writableDatabase
        var contentValues =ContentValues()
        contentValues.put(COURSE_KEY_DAY_OF_WEEK, course.dayOfWeek)
        contentValues.put(COURSE_KEY_TIME_OF_COURSE, course.timeOfCourse)
        contentValues.put(COURSE_KEY_CAPACITY, course.capacity)
        contentValues.put(COURSE_KEY_DURATION, course.duration)
        contentValues.put(COURSE_KEY_PRICE_PER_CLASS, course.pricePerClass)
        contentValues.put(COURSE_KEY_TYPE_OF_CLASS, course.typeOfClass)
        contentValues.put(COURSE_KEY_DESCRIPTION, course.description)
        contentValues.put(COURSE_KEY_STR1, course.str1)
        contentValues.put(COURSE_KEY_STR2, course.str2)
        contentValues.put(COURSE_KEY_NUM1, course.num1)
        contentValues.put(COURSE_KEY_NUM2, course.num2)
        val success = db.update(TABLE_COURSE, contentValues,"id="+course.id,null)
        db.close(); return success
    }

    fun deleteCourse(id: Int?):Int{
        val db = this.writableDatabase
        val success = db.delete(TABLE_COURSE,"id=$id",null)
        db.close()
        return success
    }

    fun viewCourse(): ArrayList<Course>{
        val courseList:ArrayList<Course> = ArrayList<Course>()
        val selectQuery = "SELECT * FROM $TABLE_COURSE"
        val db = this.readableDatabase
        var cursor: Cursor? = null
        try{
            cursor = db.rawQuery(selectQuery, null)
        }catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        if (cursor.moveToFirst()) {
            do {
                var course = Course(
                    cursor.getInt(cursor.getColumnIndex(COURSE_KEY_ID)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_DAY_OF_WEEK)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_TIME_OF_COURSE)),
                    cursor.getInt(cursor.getColumnIndex(COURSE_KEY_CAPACITY)),
                    cursor.getInt(cursor.getColumnIndex(COURSE_KEY_DURATION)),
                    cursor.getDouble(cursor.getColumnIndex(COURSE_KEY_PRICE_PER_CLASS)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_TYPE_OF_CLASS)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_DESCRIPTION)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_STR1)),
                    cursor.getString(cursor.getColumnIndex(COURSE_KEY_STR2)),
                    cursor.getDouble(cursor.getColumnIndex(COURSE_KEY_NUM1)),
                    cursor.getDouble(cursor.getColumnIndex(COURSE_KEY_NUM2)) )
                courseList.add(course)
            } while (cursor.moveToNext())
        }
        return courseList
    }

    fun deleteAll():Int{
        val db = this.writableDatabase
        val success = db.delete(TABLE_COURSE,null,null)
        db.close()
        return success
    }

    fun addInstance(instance: Instance): Long{
        var db =this.writableDatabase
        var contentValues =ContentValues()

        contentValues.put(INSTANCE_KEY_COURSE_ID, instance.courseId)
        contentValues.put(INSTANCE_KEY_DATE, instance.date)
        contentValues.put(INSTANCE_KEY_TEACHER, instance.teacher)
        contentValues.put(INSTANCE_KEY_COMMENT, instance.comment)
        val success = db.insert(TABLE_INSTANCE, null, contentValues)
        db.close(); return success
    }

    fun updateInstance(instance: Instance): Int{
        var db =this.writableDatabase
        var contentValues =ContentValues()

        contentValues.put(INSTANCE_KEY_COURSE_ID, instance.courseId)
        contentValues.put(INSTANCE_KEY_DATE, instance.date)
        contentValues.put(INSTANCE_KEY_TEACHER, instance.teacher)
        contentValues.put(INSTANCE_KEY_COMMENT, instance.comment)
        val success = db.update(TABLE_INSTANCE, contentValues,"id="+instance.id,null)
        db.close(); return success
    }

    fun deleteInstance(id: Int?):Int{
        val db = this.writableDatabase
        val success = db.delete(TABLE_INSTANCE,"id=$id",null)
        db.close()
        return success
    }

    fun viewInstance(courseId: Int): ArrayList<Instance>{
        val instanceList:ArrayList<Instance> = ArrayList<Instance>()
        val selectQuery = "SELECT * FROM $TABLE_INSTANCE WHERE $INSTANCE_KEY_COURSE_ID=$courseId"
        val db = this.readableDatabase
        var cursor: Cursor? = null
        try{
            cursor = db.rawQuery(selectQuery, null)
        }catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        if (cursor.moveToFirst()) {
            do {
                var course = Instance(
                    cursor.getInt(cursor.getColumnIndex(INSTANCE_KEY_ID)),
                    cursor.getInt(cursor.getColumnIndex(INSTANCE_KEY_COURSE_ID)),
                    cursor.getLong(cursor.getColumnIndex(INSTANCE_KEY_DATE)),
                    cursor.getString(cursor.getColumnIndex(INSTANCE_KEY_TEACHER)),
                    cursor.getString(cursor.getColumnIndex(INSTANCE_KEY_COMMENT)) )
                instanceList.add(course)
            } while (cursor.moveToNext())
        }
        return instanceList
    }
}