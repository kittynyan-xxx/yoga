package edu.uog.yogaapp.data

class Instance (var id: Int?, var courseId: Int?, var date: Long?,
                var teacher: String?, var comment: String?)