package edu.uog.yogaapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import android.widget.Toast
import edu.uog.yogaapp.data.Course
import edu.uog.yogaapp.data.CourseDetailActivity
import edu.uog.yogaapp.data.CourseListAdapter
import edu.uog.yogaapp.data.DatabaseHandler


class MainActivity : AppCompatActivity() {

    lateinit var listView: ListView
    lateinit var courseListAdapter: CourseListAdapter
    var courseList: ArrayList<Course> =ArrayList<Course>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView =findViewById(R.id.listView)
        courseListAdapter = CourseListAdapter(this, courseList)
        listView.adapter = courseListAdapter
        val obj = object :CourseListAdapter.OnClickListener{
            override fun onDetailClick(position: Int){
                var course =courseList[position]
                val intent = Intent(baseContext, CourseDetailActivity::class.java)
                intent.putExtra("ID", course.id)
                intent.putExtra("DAY_OF_WEEK", course.dayOfWeek)
                intent.putExtra("TIME_OF_COURSE", course.timeOfCourse)
                intent.putExtra("CAPACITY", course.capacity)
                intent.putExtra("DURATION", course.duration)
                intent.putExtra("PRICE", course.pricePerClass)
                intent.putExtra("TYPE_OF_CLASS", course.typeOfClass)
                intent.putExtra("DESCRIPTION", course.description)
                intent.putExtra("ADDITIONAL1", course.str1)
                intent.putExtra("ADDITIONAL2", course.str2)
                startActivity(intent)
            }
            override fun onEditClick(position: Int){
                var course =courseList[position]
                val intent = Intent(baseContext, CourseEntryActivity::class.java)
                intent.putExtra("ID", course.id)
                intent.putExtra("DAY_OF_WEEK", course.dayOfWeek)
                intent.putExtra("TIME_OF_COURSE", course.timeOfCourse)
                intent.putExtra("CAPACITY", course.capacity)
                intent.putExtra("DURATION", course.duration)
                intent.putExtra("PRICE", course.pricePerClass)
                intent.putExtra("TYPE_OF_CLASS", course.typeOfClass)
                intent.putExtra("DESCRIPTION", course.description)
                intent.putExtra("ADDITIONAL1", course.str1)
                intent.putExtra("ADDITIONAL2", course.str2)
                startActivity(intent)
            }

            override fun onRemoveClick(position: Int){
                val databaseHandler: DatabaseHandler = DatabaseHandler(baseContext)
                var status =databaseHandler.deleteCourse(courseList[position].id)
                if(status > 0){
                    Toast.makeText(baseContext,"Record deleted!", Toast.LENGTH_LONG).show()
                    viewRecord()
                }else{
                    Toast.makeText(baseContext,"Failed to delete!", Toast.LENGTH_LONG).show()
                }
            }
        }
        courseListAdapter.setOnClickListener(obj)

        viewRecord()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_list, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if( item.itemId ==R.id.action_add ){
            startActivity(Intent(baseContext, CourseEntryActivity::class.java))
            return true
        }else if( item.itemId ==R.id.action_reset ){
            resetData()
            return true
        }else if( item.itemId ==R.id.action_refresh ){
            viewRecord()
            return true
        }else
            return super.onOptionsItemSelected(item)
    }

    private fun viewRecord(){
        val databaseHandler: DatabaseHandler = DatabaseHandler(this)
        courseList = databaseHandler.viewCourse()
        courseListAdapter.courseList =courseList
        courseListAdapter.notifyDataSetChanged()
    }

    private fun resetData(){
        val databaseHandler: DatabaseHandler = DatabaseHandler(this)
        databaseHandler.deleteAll()
        viewRecord()
    }
}